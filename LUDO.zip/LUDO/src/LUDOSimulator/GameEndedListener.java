package LUDOSimulator;

public interface GameEndedListener {
	public void gameEnded(int[] result);
}
